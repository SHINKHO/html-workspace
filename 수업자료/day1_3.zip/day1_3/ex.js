function fn_over(obj){
    console.log('콜솔에 프린트됨.');
    console.log(obj);
    obj.src = 'media/딸기.png';
}
function fn_out(obj){
    obj.src = 'media/바나나.png';
}